@extends('frontend.layouts.app') 
@section('content')
 
    
            

            <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
                 

                <div class="mt-8 bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                    <div class="grid grid-cols-1 md:grid-cols-2">
                        <div class="p-6 border-t border-gray-200 dark:border-gray-700 md:border-l">
                             <h1>Wel-come to visitors</h1>
                        </div>
                    </div>
                </div>

                 
            </div>
         
@endsection