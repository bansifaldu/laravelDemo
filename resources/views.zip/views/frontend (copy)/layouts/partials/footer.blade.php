 
{{-- <footer>
    <div class="footer bg-white shadow">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-b">
            <div class="footer-copyright text-center py-3">Laravel Demo By:
                <a> Bansi Faldu</a>
            </div>
        </nav>
    </div>
</footer> --}}
<footer class="page-footer font-small blue">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">Laravel Demo By:
      <a> Bansi Faldu</a>
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer -->