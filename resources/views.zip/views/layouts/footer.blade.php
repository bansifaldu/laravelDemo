<footer>
<div class="footer">
       
    <nav class="navbar navbar-expand-md navbar-light bg-white shadow-b">
            <div class="container">
                    <p class="navbar-brand" >
                        This is footer
                    </p>
                
            </div>
        </nav>
</div>
</footer>