<!DOCTYPE html>
<html>
<head>
    <title>Registration successfully</title>
</head>
<body>
     <h1>Hello {{ $user['name'] }} </h1>
     

    <p>Thank you for registration</p>
</body>
</html>